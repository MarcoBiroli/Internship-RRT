#include "common_func.h"

QPair<double, QVector<Point>> connect(painter_widget *paintArea, Point A, Point B, Robot robot, QVector<QRectF> obstacles, bool draw){
    B.setT(sawtooth(B.theta() + M_PI, 0));
    QPair<double, QPair<QVector<Point>, QVector<double>>> connection = robot.min_dist(A, B, paintArea);
    if(!is_path_valid(paintArea, connection.second.first, obstacles)){
        return QPair<double, QVector<Point>>(INFINITY, QVector<Point>());
    }
    if(draw){
        paintArea->add_connection("1Green", QColor(0, 255, 0, 255), connection.second);
    }
    return QPair<double, QVector<Point>>(connection.first, connection.second.first);
}

QPair<double, QVector<Point>> connect(painter_widget *paintArea, Point A, Point B, Robot robot, QVector<QRectF> obstacles){
    B.setT(sawtooth(B.theta() + M_PI, 0));
    QPair<double, QPair<QVector<Point>, QVector<double>>> connection = robot.min_dist(A, B, paintArea);
    if(!is_path_valid(paintArea, connection.second.first, obstacles)){
        return QPair<double, QVector<Point>>(INFINITY, QVector<Point>());
    }
    paintArea->add_connection("1Green", QColor(0, 255, 0, 255), connection.second);
    return QPair<double, QVector<Point>>(connection.first, connection.second.first);
}
