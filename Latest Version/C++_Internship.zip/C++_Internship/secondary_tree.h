#ifndef SECONDARY_TREE_H
#define SECONDARY_TREE_H

#include <QPair>
#include <QtCore>
#include <QMap>
#include <QtGui>
#include <QVector>
#include "point.h"
#include "node.h"
#include "common.h"
#include "painter_widget.h"
#include "path.h"
#include "robot.h"
#include "common_func.h"
#include "tree.h"

class secondary_tree
{
public:
    secondary_tree(){

    }
    secondary_tree(Point node, double radius, int max_nodes, double x_min, double x_max, double y_min, double y_max);
    secondary_tree(QMap<int, Point> iroots, int max_nodes, double x_min, double x_max, double y_min, double y_max);
    QVector<QPair<int, Point>> grow_tree_dubin(painter_widget* paintArea, double step, QVector<QRectF> obstacles, Robot robot, QString scolor, QColor color);
    Tree subdue(painter_widget *paintArea, QPair<int, Point> connection_point, int starting_id, double starting_distance);
    QPair<int, Point> find_closest(Point np);
private:
    QVector<Point> roots = QVector<Point>();
    QVector<Tree> clockwise_trees = QVector<Tree>();
    QVector<Tree> anticlockwise_trees =  QVector<Tree>();
    double max_nodes = INFINITY;
    double x_min = 0;
    double x_max = INFINITY;
    double y_min = 0;
    double y_max = INFINITY;
};

#endif // SECONDARY_TREE_H
