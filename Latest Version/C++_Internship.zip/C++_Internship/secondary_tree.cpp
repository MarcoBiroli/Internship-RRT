#include "secondary_tree.h"

secondary_tree::secondary_tree(Point root, double radius, int imax_nodes, double ix_min, double ix_max, double iy_min, double iy_max)
{
    this->roots = QVector<Point>();
    this->anticlockwise_trees = QVector<Tree>();
    this->clockwise_trees = QVector<Tree>();
    QVector<Point> roots = {root + Point(0, radius), root + Point(-radius, 0), root + Point(0, -radius), root + Point(radius, 0)};
    QVector<double> angles = {M_PI, M_PI/2, 0, 3*M_PI/2};
    Point croot;
    for(int i = 0; i < 4; ++i){
        croot = roots[i];
        croot.setT(angles.at(i));
        this->clockwise_trees.append(Tree(croot));
        croot.setT(sawtooth(angles.at(i) + M_PI, 0));
        this->anticlockwise_trees.append(Tree(croot));
    }
    this->max_nodes= imax_nodes;
    this->x_min = ix_min;
    this->x_max = ix_max;
    this->y_min = iy_min;
    this->y_max = iy_max;
}

secondary_tree::secondary_tree(QMap<int, Point> iroots, int imax_nodes, double ix_min, double ix_max, double iy_min, double iy_max){
    this->roots = QVector<Point>();
    this->anticlockwise_trees = QVector<Tree>();
    this->clockwise_trees = QVector<Tree>();
    QMap<int, Point>::iterator i;
    for(i = iroots.begin(); i != iroots.end(); ++i){
        this->roots.append(i.value());
        if(i.key() == 0){
            this->clockwise_trees.append(Tree(i.value()));
        }
        else{
            this->anticlockwise_trees.append(Tree(i.value()));
        }
    }
    this->max_nodes= imax_nodes;
    this->x_min, this->x_max, this->y_min, this->y_max = ix_min, ix_max, iy_min, iy_max;
}

QVector<QPair<int, Point>> secondary_tree::grow_tree_dubin(painter_widget *paintArea, double step, QVector<QRectF> obstacles, Robot robot, QString scolor, QColor color){
    QVector<QPair<int, Point>> out = QVector<QPair<int, Point>>();
    for(int i = 0; i < 4; ++i){
        if(!this->clockwise_trees.isEmpty()){
            if (this->clockwise_trees[i].nodes.size() < this->max_nodes){
                out.append(this->clockwise_trees[i].grow_tree_dubin(paintArea, step, obstacles, robot, scolor, color, this->x_min, this->x_max, this->y_min, this->y_max));
            }
        }
        if(!this->anticlockwise_trees.isEmpty()){
            if (this->anticlockwise_trees[i].nodes.size() < this->max_nodes){
                out.append(this->anticlockwise_trees[i].grow_tree_dubin(paintArea, step, obstacles, robot, scolor, color, this->x_min, this->x_max, this->y_min, this->y_max));
            }
        }
    }
    return out;
}

QPair<int, Point> secondary_tree::find_closest(Point np){
    QPair<int, Point> out;
    QPair<double, QPair<int, Point>> cp;
    double min_dist = INFINITY;
    for(int i = 0; i < 4; ++i){
        if(!this->clockwise_trees.isEmpty()){
            cp = this->clockwise_trees[i].find_nearest(np, min_dist);
            if (cp.first < min_dist && cp.second.first != -1){
                out = cp.second;
                min_dist = cp.first;
            }
        }
        if(!this->anticlockwise_trees.isEmpty()){
            cp = this->anticlockwise_trees[i].find_nearest(np, min_dist);
            if (cp.first < min_dist && cp.second.first != -1){
                out = cp.second;
                min_dist = cp.first;
            }
        }
    }
    return out;
}

Tree secondary_tree::subdue(painter_widget *paintArea, QPair<int, Point> connection_point, int start_id, double starting_distance){
    Tree out = Tree(connection_point.second, start_id, starting_distance);
    Tree ct;
    int found = 0;
    foreach(ct, this->clockwise_trees){
        if(ct.nodes[connection_point.first] == connection_point.second){
            found = 1;
            break;
        }
    }
    if (found == 0){
        foreach(ct, this->anticlockwise_trees){
            if(ct.nodes[connection_point.first] == connection_point.second){
                found = 2;
                break;
            }
        }
    }
    assert(found != 0);
    QPair<double, QVector<QPair<QPair<int, Point>, QPair<int, Point>>>> retracing = ct.retrace(connection_point);
    QPair<QPair<int, Point>, QPair<int, Point>> edge;
    int node_id;
    int ct_root_id = -1;
    foreach(edge, retracing.second){
        node_id = out.addNode(edge.first.second);
        if(edge.first.second == ct.root){
            ct_root_id = node_id;
        }
        out.addEdge(node_id - 1, node_id);
        paintArea->reassign(edge, node_id);
    }
    if (ct_root_id == -1){
        ct_root_id = out.addNode(ct.root);
        out.addEdge(node_id, ct_root_id);
    }
    QVector<Tree> iter;
    if(found == 1){
        iter = this->anticlockwise_trees;
        this->anticlockwise_trees.clear();
    }
    else if (found == 2){
        iter = this->clockwise_trees;
        this->clockwise_trees.clear();
    }
    Tree other;
    foreach(other, iter){
        node_id = out.addNode(other.root);
        out.addEdge(ct_root_id, node_id);
        QSet<int> seen = QSet<int>({0});
        QMap<int, int> cor_switch = QMap<int, int>();
        cor_switch[0] = node_id;
        QMap<int, QVector<int>>::iterator i;
        for(i = other.forward_links.begin(); i != other.forward_links.end(); ++i){
            if (!seen.contains(i.key())){
                cor_switch[i.key()] = out.addNode(other.nodes[i.key()]);
                seen.insert(i.key());
            }
            int j;
            foreach(j, i.value()){
                if(!seen.contains(j)){
                    cor_switch[j] = out.addNode(other.nodes[j]);
                    seen.insert(j);
                }
                out.addEdge(cor_switch[i.key()], cor_switch[j]);
                paintArea->switch_path_color_and_key("1Purple", "1Green", QColor(0, 255, 0, 255), i.key(), ct.nodes[j], cor_switch[i.key()]);
            }
        }
    }
    return out;
}
