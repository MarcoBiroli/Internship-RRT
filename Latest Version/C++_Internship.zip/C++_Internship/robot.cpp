#include "robot.h"

Robot::Robot()
{

}

Robot::Robot(double si, double Li, double max_anglei)
{
    this->L = Li;
    this->s = si;
    this->max_angle = max_anglei;
    this->rho = si*1/(si/Li * qTan(max_anglei));
}

double dist(QPointF node1, QPointF node2){
    return qSqrt(qPow(node1.x() - node2.x(), 2) + qPow(node1.y() - node2.y(), 2));
}

QPair<double, QPair<QVector<Point>, QVector<double>>> Robot::min_dist(Point node0, Point node1, painter_widget *paintArea){
    /*
    Point node0bar = node0.NormByRho(this->rho);
    Point node1bar = node1.NormByRho(this->rho);
    QPair<QVector<double>, double> LSL = min_LSL(node0bar, node1bar);
    QPair<QVector<double>, double> RSL = min_RSL(node0bar, node1bar);
    QPair<QVector<double>, double> RSR = min_RSR(node0bar, node1bar);
    QPair<QVector<double>, double> LSR = min_LSR(node0bar, node1bar);
    QPair<QVector<double>, double> RLR = min_RLR(node0bar, node1bar);
    QPair<QVector<double>, double> LRL = min_LRL(node0bar, node1bar);
    double min = std::min({LSL.second, RSL.second, RSR.second, LSR.second, RLR.second, LRL.second});
    if (min == LSL.second){
        return QPair<QPair<QString, QVector<double>>, double>(QPair<QString, QVector<double>>("LSL", LSL.first), min*this->rho);
    }
    if (min == RSL.second){
        return QPair<QPair<QString, QVector<double>>, double>(QPair<QString, QVector<double>>("RSL", RSL.first), min*this->rho);
    }
    if (min == RSR.second){
        return QPair<QPair<QString, QVector<double>>, double>(QPair<QString, QVector<double>>("RSR", RSR.first), min*this->rho);
    }
    if (min == LSR.second){
        return QPair<QPair<QString, QVector<double>>, double>(QPair<QString, QVector<double>>("LSR", LSR.first), min*this->rho);
    }
    if (min == RLR.second){
        return QPair<QPair<QString, QVector<double>>, double>(QPair<QString, QVector<double>>("RLR", RLR.first), min*this->rho);
    }
    if (min == LRL.second){
        return QPair<QPair<QString, QVector<double>>, double>(QPair<QString, QVector<double>>("LRL", LRL.first), min*this->rho);
    }
    */
    QPair<double, QPair<QVector<Point>, QVector<double>>> LSL = this->find_L(node0, node1, 1, 1);
    QPair<double, QPair<QVector<Point>, QVector<double>>> LSR = this->find_L(node0, node1, 1, -1);
    QPair<double, QPair<QVector<Point>, QVector<double>>> RSL = this->find_L(node0, node1, -1, 1);
    QPair<double, QPair<QVector<Point>, QVector<double>>> RSR = this->find_L(node0, node1, -1, -1);
    double min_L = std::min({LSL.first, LSR.first, RSL.first, RSR.first});
    if(min_L == -1){
        return QPair<double, QPair<QVector<Point>, QVector<double>>>(-1, QPair<QVector<Point>, QVector<double>>());
    }
    if (min_L == LSL.first){
        //paintArea->add_connection("9Black", QColor(0, 0, 0, 255), LSL.second);
        return LSL;
    }
    if (min_L == LSR.first){
        //paintArea->add_connection("9Black", QColor(0, 0, 0, 255), LSR.second);
        return LSR;
    }
    if (min_L == RSL.first){
        //paintArea->add_connection("9Black", QColor(0, 0, 0, 255), RSL.second);
        return RSL;
    }
    if (min_L == RSR.first){
        //paintArea->add_connection("9Black", QColor(0, 0, 0, 255), RSR.second);
        return RSR;
    }
}

double Robot::min_dist(Point node0, Point node1){
    QPair<double, QPair<QVector<Point>, QVector<double>>> LSL = this->find_L(node0, node1, 1, 1);
    QPair<double, QPair<QVector<Point>, QVector<double>>> LSR = this->find_L(node0, node1, 1, -1);
    QPair<double, QPair<QVector<Point>, QVector<double>>> RSL = this->find_L(node0, node1, -1, 1);
    QPair<double, QPair<QVector<Point>, QVector<double>>> RSR = this->find_L(node0, node1, -1, -1);
    return std::min({LSL.first, LSR.first, RSL.first, RSR.first});
}

QPair<double, QPair<QVector<Point>, QVector<double>>> Robot::find_L(Point node0, Point node1, int epsa, int epsb){
    /*
    Point ca = Point(node0.x() - epsa*this->rho*qSin(node0.theta()), node0.y() + epsa*this->rho*qCos(node0.theta()));
    Point cb = Point(node1.x() - epsb*this->rho*qSin(node1.theta()), node1.y() + epsa*this->rho*qCos(node1.theta()));
    */
    Point ca = node0 + Point(-qSin(node0.theta()), qCos(node0.theta()))*(epsa*this->rho);
    Point cb = node1 + Point(-qSin(node1.theta()), qCos(node1.theta()))*(epsb*this->rho);
    if(node0 == node1){
        return QPair<double, QPair<QVector<Point>, QVector<double>>>(0, QPair<QVector<Point>, QVector<double>>());
    }
    if(ca == cb){
        return QPair<double, QPair<QVector<Point>, QVector<double>>>(-1, QPair<QVector<Point>, QVector<double>>());
    }
    double l;
    double alpha;
    if (epsa*epsb == -1){
        double lsquare = 0.25*qPow(distance(ca, cb), 2)-qPow(this->rho, 2);
        if (lsquare < 0){
            l = INFINITY;
            return QPair<double, QPair<QVector<Point>, QVector<double>>>(l, QPair<QVector<Point>, QVector<double>>());
        }
        else{
            l = qSqrt(lsquare);
        }
        alpha = -epsa * qAtan2(l, this->rho);
    }
    else{
        l = 0.5*distance(ca, cb);
        alpha = -epsa*M_PI/2;
    }

    //QPair<double, double> da1 = QPair<double, double>(ca.x() + (this->rho/distance(ca, cb)) * (qCos(alpha)*(cb.x() - ca.x()) - qSin(alpha)*(cb.y() - ca.y())),
    //                                                 ca.y() + (this->rho/distance(ca, cb)) * (qSin(alpha)*(cb.x() - ca.x()) + qCos(alpha)*(cb.y() - ca.y())));
    //QPair<double, double> db1 = QPair<double, double>(cb.x() + epsa*epsb*(da1.first - ca.x()), cb.y() + epsa*epsb*(da1.second - ca.y()));

    Point da = ca + Point((qCos(alpha)*(cb.x() - ca.x()) - qSin(alpha)*(cb.y() - ca.y())),
                                                          (qSin(alpha)*(cb.x() - ca.x()) + qCos(alpha)*(cb.y() - ca.y())))*(this->rho/distance(ca, cb));
    Point db = cb + (da - ca)*(epsa*epsb);
    double angle1 = angle(node0 - ca, da - ca);
    double betaa = sawtooth(angle1, epsa);
    double angle2 = angle(db - cb, node1 - cb);
    double betab = sawtooth(angle2, epsb);
    double L = this->rho*(fabs(betaa) + fabs(betab)) + 2*l;
    QVector<Point> outp = QVector<Point>({node0, ca, da, db, cb, node1});
    QVector<double> outd = QVector<double>({betaa, betab});
    QPair<QVector<Point>, QVector<double>> out2 = QPair<QVector<Point>, QVector<double>>(outp, outd);
    return QPair<double, QPair<QVector<Point>, QVector<double>>>(L, out2);
}

/*
QPair<QVector<double>, double> Robot::min_LSL(Point node0, Point node1){
    double tx = node1.x() - node0.x() + qSin(node0.theta()) - qSin(node1.theta());
    double ty = node1.y() - node0.y() - qCos(node0.theta()) + qCos(node1.theta());
    double phi = qAtan(ty/tx);
    double d = distance(node0, node1);
    double A;
    if (tx > 0){
        A = phi;
    }
    else if (tx < 0){
        A = phi + M_PI;
    }
    else{
        return QPair<QVector<double>, double>(QVector<double>({0, 0, 0}), INFINITY);
    }
    double dbar = qPow(d, 2) + 2 - 2*qCos(node0.theta() - node1.theta()) + 2*(node1.x() - node0.x())*
            (qSin(node0.theta()) - qSin(node1.theta())) + 2*(node1.y() - node0.y())*(qCos(node1.theta()) - qCos(node0.theta()));
    return QPair<QVector<double>, double>(QVector<double>({fmod((A - node0.theta()),(2*M_PI)),
                                                           qSqrt(dbar)*this->rho,
                                                           fmod((node1.theta() - A),(2*M_PI))}),
                                          qSqrt(dbar) + fabs(this->rho*fmod((A - node0.theta()),(2*M_PI))) + fabs(this->rho*fmod((node1.theta() - A),(2*M_PI))));
}

QPair<QVector<double>, double> Robot::min_RSL(Point node0, Point node1){
    double tx = node1.x() - node0.x() - qSin(node0.theta()) - qSin(node1.theta());
    double ty = node1.y() - node0.y() + qCos(node0.theta()) + qCos(node1.theta());
    double phi = qAtan(tx/ty);
    double d = distance(node0, node1);
    double A;
    if (ty > 0){
        A = phi + M_PI;
    }
    else if (ty < 0){
        A = phi;
    }
    else{
        return QPair<QVector<double>, double>(QVector<double>({0, 0, 0}), INFINITY);
    }
    double dbar = qPow(d, 2) - 2 + 2*qCos(node0.theta() - node1.theta()) - 2*(node1.x() - node0.x())*
            (qSin(node0.theta()) + qSin(node1.theta())) + 2*(node1.y() - node0.y())*(qCos(node1.theta()) + qCos(node0.theta()));
    double B = qAtan(qSqrt(dbar)/2);
    return QPair<QVector<double>, double>(QVector<double>({fmod((node0.theta() - B + A),(2*M_PI)),
                                                           qSqrt(dbar)*this->rho,
                                                          fmod((node1.theta() - B + A),(2*M_PI))}),
                                          qSqrt(dbar) + fabs(this->rho*fmod((node0.theta() - B + A),(2*M_PI))) + fabs(this->rho*fmod((node1.theta() - B + A),(2*M_PI))));
}

QPair<QVector<double>, double> Robot::min_RSR(Point node0, Point node1){
    double tx = node1.x() - node0.x() - qSin(node0.theta()) + qSin(node1.theta());
    double ty = node1.y() - node0.y() + qCos(node0.theta()) - qCos(node1.theta());
    double phi = qAtan(ty/tx);
    double d = distance(node0, node1);
    double A;
    if (tx > 0){
        A = phi;
    }
    else if (tx < 0){
        A = phi + M_PI;
    }
    else{
        return QPair<QVector<double>, double>(QVector<double>({0, 0, 0}), INFINITY);
    }
    double dbar = qPow(d, 2) + 2 - 2*qCos(node0.theta() - node1.theta()) + 2*(node1.x() - node0.x())*
            (qSin(node1.theta()) - qSin(node0.theta())) + 2*(node1.y() - node0.y())*(qCos(node0.theta()) - qCos(node1.theta()));
    return QPair<QVector<double>, double>(QVector<double>({fmod((node0.theta() - A),(2*M_PI)),
                                                           qSqrt(dbar)*this->rho,
                                                          fmod((A - node1.theta()),(2*M_PI))}),
                                          qSqrt(dbar) + fabs(this->rho*fmod((node0.theta() - A),(2*M_PI))) + fabs(this->rho*fmod((A - node1.theta()),(2*M_PI))));
}
QPair<QVector<double>, double> Robot::min_LSR(Point node0, Point node1){
    double tx = node1.x() - node0.x() + qSin(node0.theta()) + qSin(node1.theta());
    double ty = node1.y() - node0.y() - qCos(node0.theta()) - qCos(node1.theta());
    double phi = qAtan(-tx/ty);
    double d = distance(node0, node1);
    double A;
    if (ty > 0){
        A = phi + M_PI;
    }
    else if (ty < 0){
        A = phi;
    }
    else{
        return QPair<QVector<double>, double>(QVector<double>({0, 0, 0}), INFINITY);
    }
    double dbar = qPow(d, 2) - 2 + 2*qCos(node0.theta() - node1.theta()) + 2*(node1.x() - node0.x())*
            (qSin(node0.theta()) + qSin(node1.theta())) - 2*(node1.y() - node0.y())*(qCos(node1.theta()) + qCos(node0.theta()));
    double B = qAtan(qSqrt(dbar)/2);
    return QPair<QVector<double>, double>(QVector<double>({fmod((A - B - node0.theta()),(2*M_PI)),
                                                           qSqrt(dbar)*this->rho,
                                                          fmod((A - B - node1.theta()),(2*M_PI))}),
                                          qSqrt(dbar) + fabs(this->rho*fmod((A - B - node0.theta()),(2*M_PI))) + fabs(this->rho*fmod((A - B - node1.theta()),(2*M_PI))));
}

QPair<QVector<double>, double> Robot::min_LRL(Point node0, Point node1){
    double tx = node1.x() - node0.x() + qSin(node0.theta()) - qSin(node1.theta());
    double ty = node1.y() - node0.y() - qCos(node0.theta()) + qCos(node1.theta());
    double phi = qAtan(ty/tx);
    double d = distance(node0, node1);
    double A;
    if (tx > 0){
        A = phi;
    }
    else if (tx < 0){
        A = phi + M_PI;
    }
    else{
        return QPair<QVector<double>, double>(QVector<double>({0, 0, 0}), INFINITY);
    }
    double dbar = 1/8*(6 - qPow(d, 2) - 2*qCos(node0.theta() - node1.theta()) - 2*(node1.x() - node0.x())*
            (qSin(node0.theta()) - qSin(node1.theta())) + 2*(node1.y() - node0.y())*(qCos(node1.theta()) - qCos(node0.theta())));
    double p1 = qAcos(dbar);
    double t1 = fmod((-node0.theta() + A + p1/2),(2*M_PI));
    double q1 = fmod((node1.theta() - A + p1/2),(2*M_PI));
    double p2 = 2*M_PI - qAcos(dbar);
    double t2 = fmod((-node0.theta() + A + p2/2),(2*M_PI));
    double q2 = fmod((node1.theta() - A + p2/2),(2*M_PI));
    if (fabs(this->rho*p1) + fabs(this->rho*t1) + fabs(this->rho*q1) < fabs(this->rho*p2) + fabs(this->rho*t2) + fabs(this->rho*q2)){
        return QPair<QVector<double>, double>(QVector<double>({t1, p1, q1}), fabs(this->rho*p1) + fabs(this->rho*t1) + fabs(this->rho*q1));
    }
    else{
        return QPair<QVector<double>, double>(QVector<double>({t2, p2, q2}), fabs(this->rho*p2) + fabs(this->rho*t2) + fabs(this->rho*q2));
    }
}

QPair<QVector<double>, double> Robot::min_RLR(Point node0, Point node1){
    double tx = node1.x() - node0.x() - qSin(node0.theta()) + qSin(node1.theta());
    double ty = node1.y() - node0.y() + qCos(node0.theta()) - qCos(node1.theta());
    double phi = qAtan(ty/tx);
    double d = distance(node0, node1);
    double A;
    if (tx > 0){
        A = phi;
    }
    else if (tx < 0){
        A = phi + M_PI;
    }
    else{
        return QPair<QVector<double>, double>(QVector<double>({0, 0, 0}), INFINITY);
    }
    double dbar = 1/8*(6 - qPow(d, 2) + 2*qCos(node0.theta() - node1.theta()) + 2*(node1.x() - node0.x())*
            (qSin(node0.theta()) - qSin(node1.theta())) - 2*(node1.y() - node0.y())*(qCos(node1.theta()) - qCos(node0.theta())));
    double p1 = qAcos(dbar);
    double t1 = fmod((node0.theta() - A + p1/2),(2*M_PI));
    double q1 = fmod((-node1.theta() + A + p1/2),(2*M_PI));
    double p2 = 2*M_PI - qAcos(dbar);
    double t2 = fmod((node0.theta() - A + p2/2),(2*M_PI));
    double q2 = fmod((-node1.theta() + A + p2/2),(2*M_PI));
    if (fabs(this->rho*p1) + fabs(this->rho*t1) + fabs(this->rho*q1) < fabs(this->rho*p2) + fabs(this->rho*t2) + fabs(this->rho*q2)){
        return QPair<QVector<double>, double>(QVector<double>({t1, p1, q1}), fabs(this->rho*p1) + fabs(this->rho*t1) + fabs(this->rho*q1));
    }
    else{
        return QPair<QVector<double>, double>(QVector<double>({t2, p2, q2}), fabs(this->rho*p2) + fabs(this->rho*t2) + fabs(this->rho*q2));
    }
}

QVector<Point> Robot::gen_L(Point start, double delta_theta, int nb_points){
    QVector<Point> out;
    out.append(start);
    double h = fabs((delta_theta)/(nb_points*this->s/this->L * qTan(-this->max_angle)));
    Point cp = start;
    for(int i = 0; i < nb_points; ++i){
        cp.setX(cp.x() + h*this->s * qCos(cp.theta()));
        cp.setY(cp.y() + h*this->s * qCos(cp.theta()));
        cp.setT(cp.theta() + h*this->s/this->L * qTan(-this->max_angle));
        out.append(cp);
    }
    return out;
}

QVector<Point> Robot::gen_R(Point start, double delta_theta, int nb_points){
    QVector<Point> out;
    out.append(start);
    double h = fabs((delta_theta)/(nb_points*this->s/this->L * qTan(this->max_angle)));
    Point cp = start;
    for(int i = 0; i < nb_points; ++i){
        cp.setX(cp.x() + h*this->s * qCos(cp.theta()));
        cp.setY(cp.y() + h*this->s * qCos(cp.theta()));
        cp.setT(cp.theta() + h*this->s/this->L * qTan(this->max_angle));
        out.append(cp);
    }
    return out;
}

*/

QVector<Point> Robot::go_straight(Point A, double delta_d){
    int nb = 10;
    double u_phi = 0;
    double delta_t = delta_d/(nb*this->s);
    if (delta_t < 0){
        qDebug()<<"ERROR ERROR ERROR";
    }
    return A.rk4_dubin(nb, this->s, u_phi, delta_t, this->L);
}

QVector<Point> Robot::turn_by(Point A, double delta_theta){
    int nb = 10;
    double u_phi = sign(delta_theta)*this->max_angle;
    double delta_t = fabs(delta_theta/(nb * qTan(u_phi) * this->s/this->L));
    return A.rk4_dubin(nb, this->s, u_phi, delta_t, this->L);
}
