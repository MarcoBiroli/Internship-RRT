#ifndef COMMON_H
#define COMMON_H

#include <QWidget>
#include <QtCore>
#include <QtGui>
#include <QtDebug>
#include <QVector>
#include <QRandomGenerator>
#include <QtMath>
#include "point.h"

Point lines_collided(double p0_x, double p0_y, double p1_x, double p1_y, double p2_x, double p2_y, double p3_x, double p3_y);
Point rand_point(double width, double height);
Point rand_point(double x_min, double x_max, double y_min, double y_max);
Point rand_point(Point center, double width, double height);
Point build(Point start, Point end, double step);
bool is_valid(QWidget *paintArea,  Point pp, Point np, QVector<QRectF> obstacles);
bool is_path_valid(QWidget *paintArea, QVector<Point> path, QVector<QRectF> obstacles);
double mmod(double x, double d);
double sawtooth(double x, double d);
double angle(Point u, Point v);
int sign(double x);

#endif // COMMON_H
