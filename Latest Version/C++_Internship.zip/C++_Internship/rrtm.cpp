#include "rrtm.h"

QPair<double, double> RRTm(painter_widget *paintArea, QProgressBar *progress_bar, int max_iter, bool dynamic_drawing, bool stop_when_found, double step){
    //Variable Transfer
    Point start = paintArea->get_start();
    Point end = paintArea->get_end();
    QVector<QRectF> obstacles = paintArea->get_obstacles();
    double time = -1;
    QElapsedTimer timer;
    Tree *T1;
    Tree *T2;
    QPair<int, Point>closest_pair;
    QPair<int, Point> np;
    QPair<double, QVector<QPair<QPair<int, Point>, QPair<int, Point>>>> best_path = QPair<double, QVector<QPair<QPair<int, Point>, QPair<int, Point>>>>(INFINITY, QVector<QPair<QPair<int, Point>, QPair<int, Point>>>());
    QPair<double, QVector<QPair<QPair<int, Point>, QPair<int, Point>>>> cur_path1;
    QPair<double, QVector<QPair<QPair<int, Point>, QPair<int, Point>>>> cur_path2;
    QPair<QPair<int, Point>, QPair<int, Point>> edge;
    QPair<double, QVector<Point>> mid;
    QVector<secondary_tree> sTrees = QVector<secondary_tree>();
    Robot robot(50, 15, M_PI/4);
    double secondary_node_density = 0.01;
    double p_margin = 0.33;
    QVector<int> connected_to = QVector<int>{0, 0, 0, 0};
    QVector<int> connected_to2 = QVector<int>{0, 0, 0, 0};

    // Checks
    if (start.isNull()){
        return QPair<double, double>(-1, -1);
    }
    if (end.isNull()){
        return QPair<double, double>(-1, -1);
    }


    //Program
    T1 = new Tree(start);
    T2 = new Tree(end);
    QRectF obstacle;
    double left;
    double right;
    double bottom;
    double top;
    double hz_margin;
    double vt_margin;
    double hz_max_nodes;
    double vt_max_nodes;
    foreach(obstacle, obstacles){
        left = std::min({obstacle.left(), obstacle.right()});
        right = std::max({obstacle.left(), obstacle.right()});
        bottom = std::min({obstacle.bottom(), obstacle.top()});
        top = std::max({obstacle.bottom(), obstacle.top()});
        hz_margin = (right - left)*p_margin;
        vt_margin = (top - left)*p_margin;
        hz_max_nodes = (right + hz_margin - left + hz_margin)*vt_margin*secondary_node_density;
        vt_max_nodes = (top + vt_margin - bottom + vt_margin)*hz_margin*secondary_node_density;
        sTrees.append(secondary_tree(Point(obstacle.center()) + Point(0, (fabs(obstacle.height()))/2 + robot.rho + vt_margin*0.1), robot.rho, hz_max_nodes, left - hz_margin, right + hz_margin, top, top + vt_margin));
        sTrees.append(secondary_tree(Point(obstacle.center()) + Point(0, (-fabs(obstacle.height()))/2 - robot.rho - vt_margin*0.1), robot.rho, hz_max_nodes, left - hz_margin, right + hz_margin, bottom - vt_margin, bottom));
        sTrees.append(secondary_tree(Point(obstacle.center()) + Point((fabs(obstacle.width()))/2 + robot.rho + hz_margin*0.1, 0), robot.rho, vt_max_nodes, right, right + hz_margin, bottom - vt_margin, top + vt_margin));
        sTrees.append(secondary_tree(Point(obstacle.center()) + Point((-fabs(obstacle.width()))/2 - robot.rho - hz_margin*0.1, 0), robot.rho, vt_max_nodes, left - hz_margin, left, bottom - vt_margin, top + vt_margin));
    }

    /*
    QPair<int, Point> start_node = QPair<int, Point>(0, start);
    QPair<int, Point> end_node = QPair<int, Point>(0, end);
    mid = connect(paintArea, start_node, end_node, T1, T2, robot, obstacles);
    */


    timer.start();
    for (int i = 0; i < max_iter; i++)
    {
        if (dynamic_drawing){
            paintArea->repaint();
            progress_bar->setValue((int)(100*i/max_iter));
            QCoreApplication::processEvents();
        }
        np = T1->grow_tree_dubin(paintArea, step, obstacles, robot, "1Green", QColor(0, 255, 0, 255));
        for(int i = 0; i < sTrees.length(); ++i){
            if(connected_to[i] == 1){
                continue;
            }
            sTrees[i].grow_tree_dubin(paintArea, step, obstacles, robot, "1Purple", QColor(255, 0, 255, 25));
            closest_pair = sTrees[i].find_closest(np.second);
            if(distance(np.second, closest_pair.second) <= 10){
                mid = connect(paintArea, np.second, closest_pair.second, robot, obstacles, false);
                if(mid.first != -1 && is_path_valid(paintArea, mid.second, obstacles)){
                    mid = connect(paintArea, np.second, closest_pair.second, robot, obstacles, true);
                    T1->merge(sTrees[i].subdue(paintArea, closest_pair, T1->node_id, T1->distances[np.first]), np, T1->node_id); //T1->node_id constant or modified ???
                    connected_to[i] = 1;
                }
            }
        }
        closest_pair = T2->find_nearest(np.second);
        if(np.first != -1 && distance(np.second, closest_pair.second) <= 10){
            //paintArea->clear_color("2Red");
            //paintArea->clear_color("2Blue");
            //paintArea->add_to_draw("2Red", QColor(255, 0, 0, 255), np, closest_pair.second );
            mid = connect(paintArea, np.second, closest_pair.second, robot, obstacles);
            if(mid.first == -1){
                continue;
            }
            else{
                //paintArea->add_path_to_draw("2Red", QColor(255, 0, 0, 255), np.first, mid.second);
            }
            time = timer.elapsed();
            cur_path1 = T1->retrace_dubin(np, robot);
            cur_path2 = T2->retrace_dubin(closest_pair, robot);
            if(cur_path1.first + cur_path2.first < best_path.first){
                paintArea->clear_color("2Red");
                paintArea->clear_color("2Blue");
                best_path.first = cur_path1.first + cur_path2.first;
                best_path.second = cur_path1.second;
                best_path.second.append(cur_path2.second);
                foreach(edge, cur_path1.second){
                    paintArea->switch_path_color("1Green", "2Red", QColor(255, 0, 0, 255), edge.first.first, edge.second.second);
                }
                foreach(edge, cur_path2.second){
                    paintArea->switch_path_color("1Green", "2Blue", QColor(0, 0, 255, 255), edge.first.first, edge.second.second);
                }
            }
            if(stop_when_found){
                return QPair<double, double>(best_path.first, time);
            }
        }
        np = T2->grow_tree_dubin(paintArea, step, obstacles, robot, "1Green", QColor(0, 255, 0, 255));
        for(int i = 0; i < sTrees.length(); ++i){
            if(connected_to2[i] == 1){
                continue;
            }
            closest_pair = sTrees[i].find_closest(np.second);
            if(distance(np.second, closest_pair.second) <= 10){
                mid = connect(paintArea, np.second, closest_pair.second, robot, obstacles, false);
                if(mid.first != -1 && is_path_valid(paintArea, mid.second, obstacles)){
                    mid = connect(paintArea, np.second, closest_pair.second, robot, obstacles, true);
                    T2->merge(sTrees[i].subdue(paintArea, closest_pair, T2->node_id, T2->distances[np.first]), np, T2->node_id); //T1->node_id constant or modified ???
                    connected_to2[i] = 1;
                }
            }
        }
        closest_pair = T1->find_nearest(np.second);
        if(np.first != -1 && distance(np.second, closest_pair.second) <= 10 && is_valid(paintArea, np.second, closest_pair.second, obstacles)){
            //paintArea->clear_color("2Red");
            //paintArea->clear_color("2Blue");
            //paintArea->add_to_draw("2Blue", QColor(0, 0, 255, 255), np, closest_pair.second);
            mid = connect(paintArea, np.second, closest_pair.second, robot, obstacles);
            if(mid.first == -1){
                continue;
            }
            else{
                //paintArea->add_path_to_draw("2Red", QColor(255, 0, 0, 255), np.first, mid.second);
                //paintArea->add_connection("2Red", QColor(255, 0, 0, 255), mid.s);
            }
            time = timer.elapsed();
            cur_path1 = T1->retrace_dubin(closest_pair, robot);
            cur_path2 = T2->retrace_dubin(np, robot);
            if(cur_path1.first + cur_path2.first < best_path.first){
                paintArea->clear_color("2Red");
                paintArea->clear_color("2Blue");
                best_path.first = cur_path1.first + cur_path2.first;
                best_path.second = cur_path1.second;
                best_path.second.append(cur_path2.second);
                foreach(edge, cur_path1.second){
                    paintArea->switch_path_color("1Green", "2Blue", QColor(0, 0, 255, 255), edge.first.first, edge.second.second);
                }
                foreach(edge, cur_path2.second){
                    paintArea->switch_path_color("1Green", "2Red", QColor(255, 0, 0, 255), edge.first.first, edge.second.second);
                }
            }
            if(stop_when_found){
                return QPair<double, double>(best_path.first, time);
            }
        }
    }
    if(time == -1){
        time = timer.elapsed();
    }

    return QPair<double, double>(best_path.first, time);
}
