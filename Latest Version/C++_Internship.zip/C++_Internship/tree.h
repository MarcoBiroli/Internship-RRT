#ifndef TREE_H
#define TREE_H

#include <QPair>
#include <QtCore>
#include <QMap>
#include <QtGui>
#include <QVector>
#include "point.h"
#include "node.h"
#include "common.h"
#include "painter_widget.h"
#include "path.h"
#include "robot.h"
#include "common_func.h"

class Tree{
public:
    QMap<int, QVector<int>> forward_links =  QMap<int, QVector<int>>();
    QMap<int, QVector<int>> backward_links = QMap<int, QVector<int>>();
    Point root = Point();
    int node_id = 0;
    QMap<int, Point> nodes = QMap<int, Point>();
    QMap<int, double> distances = QMap<int, double>();
    Tree(){

    }
    Tree(const Tree& other){
        this->root = other.root;
        this->forward_links = other.forward_links;
        this->backward_links = other.backward_links;
        this->max_nodes = other.max_nodes;
        this->x_max = other.x_max;
        this->y_max = other.y_max;
        this->from_paint_area = other.from_paint_area;
        this->node_id = other.node_id;
        this->nodes = other.nodes;
        this->distances = other.distances;
    }
    Tree(Point iroot);
    Tree(Point iroot, int starting_id, double starting_distance);
    Tree(Point root, int max_nodes, double x_max, double y_max);
    int addNode(Point node);
    void addEdge(int node1, int node2);
    QPair<int, Point> find_nearest(Point node);
    QPair<double, QPair<int, Point>> find_nearest(Point node, double min_dist);
    QVector<QPair<int, Point>> get_close(Point node, double rad);
    QPair<Point, Point> remove_parent_edge(QPair<int, Point> node);
    QPair<int, Point> choose_parent(painter_widget *paintArea, Point node, QVector<QPair<int, Point>> candidates, QVector<QRectF> obstacles);
    void rewire(painter_widget *paintArea, QVector<QPair<int, Point>> close_points, QPair<int, Point> new_point, QVector<QRectF> obstacles);
    bool rewire_fn(painter_widget *paintArea, QVector<QPair<int, Point>> close_points, QPair<int, Point> new_point, QVector<QRectF> obstacles);
    bool IsOnlyChild(QPair<int, Point> node);
    QVector<QPair<Point, Point>> remove_node(int node);
    QVector<QPair<Point, Point>> remove_parent(QPair<int, Point> node);
    bool force_delete(painter_widget *paintArea);
    QPair<int, QVector<Point>> find_nearest_dubin(Point node, Robot robot, double step);
    QPair<double, QPair<int, Point>> find_nearest_dubin(painter_widget *paintArea, QVector<QRectF> obstacles, Point node, Robot robot, double step, double min_dist);
    QPair<int, Point> grow_tree(painter_widget* paintArea, double step, QVector<QRectF> obstacles, QString scolor, QColor color);
    QPair<int, Point> grow_tree_dubin(painter_widget* paintArea, double step, QVector<QRectF> obstacles, Robot robot, QString scolor, QColor color);
    QPair<double, QVector<QPair<QPair<int, Point>, QPair<int, Point>>>> retrace(QPair<int, Point> fp);
    QPair<double, QVector<QPair<QPair<int, Point>, QPair<int, Point>>>> retrace_dubin(QPair<int, Point> fp, Robot robot);
    QPair<int, QVector<Point>> choose_parent_dubin(painter_widget *paintArea, Point node, QVector<QPair<int, Point>> candidates, QVector<QRectF> obstacles, Robot robot);
    QPair<int, Point> grow_tree_and_rewire_dubin(painter_widget* paintArea, double step, QVector<QRectF> obstacles, Robot robot, QString scolor, QColor color, double rad);
    QPair<int, Point> remove_parent_edge_dubin(QPair<int, Point> node);
    QPair<int, Point> grow_tree_dubin(painter_widget* paintArea, double step, QVector<QRectF> obstacles, Robot robot, QString scolor, QColor color, double ix_min, double ix_max, double iy_min, double iy_max);
    void merge(Tree other, QPair<int, Point> connection_point, int other_root_id);
private:
    double max_nodes = INFINITY;
    double x_max = INFINITY;
    double y_max = INFINITY;
    bool from_paint_area = false;
};

#endif // TREE_H
