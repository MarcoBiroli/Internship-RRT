#ifndef COMMON_FUNC_H
#define COMMON_FUNC_H

#include <QWidget>
#include <QtCore>
#include <QtGui>
#include <QtDebug>
#include <QVector>
#include <QRandomGenerator>
#include <QtMath>
#include "point.h"
#include "painter_widget.h"
#include "robot.h"
#include "tree.h"
#include "common.h"

QPair<double, QVector<Point>> connect(painter_widget *paintArea, Point A, Point B, Robot robot, QVector<QRectF> obstacles);
QPair<double, QVector<Point>> connect(painter_widget *paintArea, Point A, Point B, Robot robot, QVector<QRectF> obstacles, bool draw);

#endif // COMMON_FUNC_H
