#include "painter_widget.h"

painter_widget::painter_widget(QWidget *parent) : QWidget(parent)
{
    startPen.setColor(QColor(0, 0, 255, 255));
    startPen.setWidth(10);

    endPen.setColor(QColor(255, 0, 0, 255));
    endPen.setWidth(10);

    linePen.setColor(QColor(0, 255, 0, 255));
    linePen.setWidth(1);

    obstaclePen.setColor((QColor(255, 255, 255, 255)));
    obstaclePen.setWidth(1);

    pathPen.setColor(QColor(255, 0, 0, 255));
    pathPen.setWidth(1);
    this->setAutoFillBackground(true);

    /*
    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(repaint()));
    timer->start();
    */

}


void painter_widget::paintEvent(QPaintEvent * /* event */)
{

    QPainter painter(this);

    painter.setPen(startPen);
    painter.drawPoint(start.node);

    painter.setPen(endPen);
    painter.drawPoint(end.node);

    painter.setPen(obstaclePen);
    QRectF cur_rect;
    foreach (cur_rect, obstacles) {
        painter.fillRect(cur_rect, QColor(255,255,255,255));
    }

    QPair<Point, Point> edge;
    Point point1;
    Point point2;
    QMap<QString, QPair<QColor, QVector<QPair<Point, Point>>>>::iterator i;
    for(i = to_draw.begin(); i != to_draw.end(); ++i){
        pathPen.setColor(i.value().first);
        painter.setPen(pathPen);
        foreach(edge, i.value().second){
            point1 = edge.first;
            point2 = edge.second;
            painter.drawLine(point1.node, point2.node);
        }
    }

    QMap<QString, QPair<QColor, QMap<int, QVector<QVector<Point>>>>>::iterator j;
    for(j = paths_to_draw.begin(); j != paths_to_draw.end(); j++){
        pathPen.setColor(j.value().first);
        painter.setPen(pathPen);
        QMap<int, QVector<QVector<Point>>>::iterator k;
        for(k = j.value().second.begin(); k != j.value().second.end(); ++k){
            QVector<Point> path;
            foreach (path, k.value()) {
                for(int l = 1; l < path.length(); ++l){
                    painter.drawLine(path[l-1].node, path[l].node);
                }
            }
        }
    }

    QMap<QString, QPair<QColor, QVector<QPair<QVector<Point>, QVector<double>>>>>::iterator k;
    for (k = connections_to_draw.begin(); k != connections_to_draw.end(); ++k){
        pathPen.setColor(k.value().first);
        painter.setPen(pathPen);
        QPair<QVector<Point>, QVector<double>> connector;
        foreach(connector, k.value().second){
            // start_point, ca, end_point1, end_point2, cb, finish_point
            this->paint_arc(connector.first[0], connector.first[1], connector.second[0], &painter);
            painter.drawLine(connector.first[2].node, connector.first[3].node);
            this->paint_arc(connector.first[3], connector.first[4], connector.second[1], &painter);
        }
    }
}

void painter_widget::paint_arc(Point start_point, Point ca, double delta_angle, QPainter* painter){
    double r = distance(start_point, ca);
    QRectF rect = QRectF(ca.x() - r, ca.y() - r, 2*r, 2*r);
    //painter->drawRect(rect);
    //QRectF rect = QRectF(QPointF(ca.x() - r, ca.y() + r), QPointF(ca.x() + r, ca.y() - r));
    Point reference = Point(r, 0);
    double angle1 = angle(reference, start_point - ca);
    double start_angle = sawtooth(angle1, 1);
    painter->drawArc(rect, -5760*start_angle/(2*M_PI), -5760*delta_angle/(2*M_PI));
}

void painter_widget::add_connection(QString scolor, QColor color, QPair<QVector<Point>, QVector<double>> connection){
    this->connections_to_draw[scolor].first = color;
    this->connections_to_draw[scolor].second.append(connection);
}

void painter_widget::mousePressEvent(QMouseEvent *event)
{
    /*
    if (event->button() == Qt::LeftButton) {
        lastPoint = event->pos();
        scribbling = true;
    }
    */
    has_moved = false;
    click_point.setX(event->x());
    click_point.setY(event->y());
}

void painter_widget::mouseMoveEvent(QMouseEvent *event)
{
    /*
    if ((event->buttons() & Qt::LeftButton) && scribbling)
        drawLineTo(event->pos());
    */
    has_moved = true;
}

void painter_widget::mouseReleaseEvent(QMouseEvent *event)
{
    /*
    if (event->button() == Qt::LeftButton && scribbling) {
        drawLineTo(event->pos());
        scribbling = false;
    }
    */
    if (has_moved == false){
        QRectF container = this->in_obstacle(click_point);
        if (!container.isNull()){
            this->obstacles.remove(this->obstacles.indexOf(container));
        }
        else{
            if (event->button() == Qt::LeftButton){
                start = click_point;
            }
            if (event->button() == Qt::RightButton){
                end = click_point;
            }
        }
    }
    else{
        int dx = event->x() - click_point.x();
        int dy = event->y() - click_point.y();
        obstacles.append(QRectF(click_point.x(), click_point.y(), dx, dy));
    }
    //this->to_draw["2Delete"].second.clear();
    this->update();
}

QRectF painter_widget::in_obstacle(Point point){
    QRectF obstacle;
    foreach (obstacle, this->obstacles) {
        if(obstacle.contains(point.x(), point.y())){
            return obstacle;
        }
    }
    return QRectF();
}

Point painter_widget::get_start(){
    return this->start;
}

Point painter_widget::get_end(){
    return this->end;
}

QVector<QRectF> painter_widget::get_obstacles(){
    return this->obstacles;
}

void painter_widget::reset(){
    to_draw.clear();
    paths_to_draw.clear();
    connections_to_draw.clear();
    this->update();
}

void painter_widget::add_to_draw(QString scolor, QColor color, Point node1, Point node2)
{
    to_draw[scolor].first = color;
    to_draw[scolor].second.append(QPair<Point, Point>(node1, node2));
}

void painter_widget::delete_to_draw(QString scolor, QVector<QPair<Point, Point>> deleted_edges){
    QPair<Point, Point> edge;
    foreach(edge, deleted_edges){
        if (to_draw[scolor].second.contains(edge)){
            //this->add_to_draw("2Delete", this->palette().color(this->backgroundRole()), edge.first, edge.second);
            to_draw[scolor].second.remove(to_draw[scolor].second.indexOf(edge));
        }
    }
}

void painter_widget::delete_path_to_draw(QString scolor, QVector<QPair<int, Point>> deleted_edges){
    QPair<int, Point> edge;
    foreach(edge, deleted_edges){
        QVector<Point> path;
        for(int i = 0; i < this->paths_to_draw[scolor].second.value(edge.first).length(); ++i){
            path = this->paths_to_draw[scolor].second[edge.first].value(i);
            if(path.contains(edge.second)){
                this->paths_to_draw[scolor].second[edge.first].remove(i);
                return;
            }
        }
    }
}

void painter_widget::clear_color(QString color){
    /*
    QPair<Point, Point> edge;
    foreach (edge, this->to_draw[color].second) {
        this->add_to_draw("2Delete", this->palette().color(this->backgroundRole()), edge.first, edge.second);
    }
    */
    this->to_draw[color].second.clear();
    this->paths_to_draw[color].second.clear();
}

void painter_widget::add_path_to_draw(QString scolor, QColor color, int parent, QVector<Point> path){
    this->paths_to_draw[scolor].first = color;
    this->paths_to_draw[scolor].second[parent].append(path);
}

void painter_widget::switch_path_color(QString prev_scolor, QString scolor, QColor color, int parent, Point child){
    QVector<Point> path;
    foreach(path, this->paths_to_draw[prev_scolor].second[parent]){
        if (path.contains(child)){
            this->add_path_to_draw(scolor, color, parent, path);
            break;
        }
    }
}

void painter_widget::switch_path_color_and_key(QString prev_scolor, QString scolor, QColor color, int parent, Point child, int new_key){
    QVector<Point> path;
    foreach(path, this->paths_to_draw[prev_scolor].second[parent]){
        if (path.contains(child)){
            this->add_path_to_draw(scolor, color, new_key, path);
            this->paths_to_draw[prev_scolor].second[parent].remove(this->paths_to_draw[prev_scolor].second[parent].indexOf(path));
            break;
        }
    }
}

void painter_widget::reassign(QPair<QPair<int, Point>, QPair<int, Point>> edge, int node_id){
    QVector<Point> pp;
    foreach(pp, this->paths_to_draw["1Purple"].second[edge.first.first]){
        if(pp.contains(edge.second.second)){
            this->add_path_to_draw("1Green", QColor(0, 255, 0, 255), node_id, pp);
            this->paths_to_draw["1Purple"].second[edge.first.first].remove(this->paths_to_draw["1Purple"].second[edge.first.first].indexOf(pp));
            break;
        }
    }
}
